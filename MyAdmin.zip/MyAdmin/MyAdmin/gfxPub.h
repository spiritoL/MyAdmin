
// gfxPub.h
#ifndef _MYPUB_H_
#define _MYPUB_H_

#include"stdafx.h"

int		IocnAni;

//DSL
#endif