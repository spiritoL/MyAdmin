//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� MyAdmin.rc ʹ��
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_MyAdminTYPE                 130
#define IDC_HANDLECUR                   310
#define IDC_DRAGGING                    311
#define IDC_NODRAGGING                  312
#define IDI_ICON_LOG                    313
#define IDI_ICON_OP_LOG                 314
#define IDI_ICON_RE                     315
#define IDI_ICON_REPORT                 316
#define IDI_ICON_REQ                    317
#define IDI_ICON_SET                    318
#define IDI_ICON_USER                   319
#define IDD_FORMBACKGROUND_FORM         321
#define IDB_BITMAP_BACK                 322
#define IDD_DIALOG_CFG                  323
#define IDD_DIALOG_TRAN                 324
#define IDD_DIALOG_NETMNG               324
#define IDB_BITMAP1                     325
#define IDB_BITMAP_SECNODE              325
#define IDD_DIALOG_INITDBINFO           326
#define IDD_DIALOG_NODECREATE           327
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define IDC_EDIT3                       1002
#define IDC_BUTTON1                     1003
#define IDC_EDIT_NODEAUTH               1003
#define IDC_EDIT_SERIP                  1004
#define IDC_EDIT_DBSOURCE               1004
#define IDC_BUTTON_NODEDEL              1004
#define IDC_EDIT_NODEDESC               1004
#define IDC_EDIT_SERMAXNODE             1005
#define IDC_EDIT_DBUSER                 1005
#define IDC_BUTTON_NODEMODIFY           1005
#define IDC_EDIT_SERPORT                1006
#define IDC_EDIT_DBPW                   1006
#define IDC_BUTTON_NODEAUTH             1006
#define IDC_BUTTON_SERINFOSAVE          1007
#define IDC_BUTTON_TEST                 1007
#define IDC_EDIT7                       1008
#define IDC_EDIT8                       1009
#define IDC_LIST_SECNODE                1009
#define IDC_EDIT9                       1010
#define IDC_CHECK_TIME                  1010
#define IDC_BUTTON3                     1011
#define IDC_DATETIMEPICKER1             1011
#define IDC_DATETIMEPICKER2             1012
#define IDC_BUTTON_SEARCH               1013
#define IDC_BUTTON_NODECREATE           1014
#define IDC_EDIT_NODEID                 1015
#define IDC_EDIT_NODENAME               1016
#define IDC_EDITNODESTATE               1017
#define ID_GFX_SMALLICON                50000
#define ID_GFX_LARGEICON                50001
#define ID_GFX_RENAMEITEM               50002
#define ID_GFX_REMOVEITEM               50003
#define ID_GFX_GROUPICON                50004
#define ID_GFX_FONTCICON                50005
#define ID_GFX_BACKCICON                50006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        328
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
